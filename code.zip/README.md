# ClickViral v2

ClickViral social media and instant messenger 

[Version 1](https://clickviral.pythonanywhere.com)
