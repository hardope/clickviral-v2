import isUserorReadonly from './user';
import isAdmin from './admin';

export { isUserorReadonly, isAdmin }